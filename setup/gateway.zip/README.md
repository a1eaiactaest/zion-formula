# Zion Gateway

***Gateway allows users to bind port to tunnel requests to the onion service***
## Usage Guide

Gateway doesn't come with tor statically linked or preinstalled so please make sure that you have it installed and running.

If you want to build it from source: [Github Mirror](https://github.com/torproject/tor)

Then run it in screen/terminal or install as daemon for your os

### Building & Running

- First check the hashsum of the zip file
- Unpack the file
- cd gateway/
- Install Go for your os
- Run `go mod download` to download packages
- You can verfiy the packages by running `go mod verify`
- Build binary by running `go build zion-gateway.go`
- Execute by running `./zion-gateway` ( for linux/unix )

### Connecting

Then at your matrix client you set your matrix homeserver as 127.0.0.1:8008 (Or other port)

If everything is running correctly you should be logged in on your client

### Program Flags

> -d=true Turns on the debug mode on (Default:false)

> -r example.onion Sets the forwarding to the provided onion address(Default:zion)

> -g=true Sets the guest mode on, which removes the user-agent from http requests(Default:false)

> -s 0000 Sets the tor socks port to use (Default:9050)

> -l 0000 Sets port to listen on (Default:8008)
