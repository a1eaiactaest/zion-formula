/*
DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
Version 2, February 2022

Copyright (C) 2022 Nullbyte @nullbyte:zion

Everyone is permitted to copy and distribute verbatim or modified
copies of this license document, and changing it is allowed as long
as the name is changed.

DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

0. You just DO WHAT THE FUCK YOU WANT TO.
*/
package main

import (
	"context"
	"flag"
	"log"
	"net"
	"net/http"
	"net/http/httputil"

	"golang.org/x/net/proxy"
)

var (
	debug        *bool   = flag.Bool("d", false, "Turns on debug mode")
	destination  *string = flag.String("r", "zion244k2d5snr6uao5mxukpacqbr4z25oaji5kegjw43ypd72pri3qd.onion", "Address of onion server")
	guestMode    *bool   = flag.Bool("g", false, "Removes the user-agent from the request")
	torSocksPort *string = flag.String("s", "9050", "Tor socks port for connection")
	listenerPort *string = flag.String("l", "8008", "Default port to listen")
)

func proxyHandler(w http.ResponseWriter, r *http.Request) {
	//* Change the destination to the tor address
	r.Host = *destination
	if *guestMode {
		r.Header.Del("User-Agent")
	}
	//* Dial the tor socks proxy
	dialer, err := proxy.SOCKS5("tcp", "127.0.0.1:"+*torSocksPort, nil, proxy.Direct)
	if err != nil {
		panic(err)
	}
	dialContext := func(ctx context.Context, network, address string) (net.Conn, error) {
		return dialer.Dial(network, address)
	}
	//* Setup the proxy with the director and tor socks proxy
	proxytransport := &http.Transport{DialContext: dialContext, DisableKeepAlives: false}
	proxy := &httputil.ReverseProxy{
		Transport: proxytransport,
		Director:  proxyDirector(r),
	}
	proxy.ServeHTTP(w, r)
}

func proxyDirector(r *http.Request) func(*http.Request) {
	return func(req *http.Request) {
		req.URL.Scheme = "http"
		req.URL.Host = r.Host
		if *debug {
			//* Dump the whole request
			reqLog, err := httputil.DumpRequestOut(req, false)
			if err != nil {
				log.Printf("Got error %s\n %+v\n", err.Error(), req)
			}
			log.Println(string(reqLog))
		} else {
			reqlog := string(req.Method) + string(req.RequestURI)
			log.Println(string(reqlog))
		}
	}
}

func main() {
	log.Println("Starting Gateway")
	flag.Parse()
	http.HandleFunc("/", proxyHandler)
	log.Fatal(http.ListenAndServe(":"+*listenerPort, nil))
	// TODO: Implement I2P, although it should be similar just using http not socks
}
